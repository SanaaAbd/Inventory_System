 public enum ItemType {
    WEAPON,ARMOUR,OTHER
}
